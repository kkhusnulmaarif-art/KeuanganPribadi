# Keuangan Pribadi — proyek Android

Proyek Android Studio sederhana dengan antarmuka offline berbasis HTML lokal di dalam WebView. Data transaksi dan jumlah pecahan uang disimpan pada localStorage di perangkat (tidak dikirim ke server).

## Fitur prototipe
- Satu saldo rekening dan satu saldo tercatat dompet.
- Saldo awal rekening/dompet, pemasukan, pengeluaran, transfer rekening ↔ dompet.
- Kategori pengeluaran: Bensin, Makan, Jajan, Kencan, Kos, Cicilan, Operasional Lain.
- Uang fisik: lembar Rp100.000, Rp50.000, Rp20.000, Rp10.000, Rp5.000, Rp2.000, Rp1.000 dan koin Rp1.000, Rp500, Rp200, Rp100.
- Penyesuaian uang fisik terpisah dari saldo tercatat dompet.
- Riwayat transaksi, edit/hapus, dan laporan bulanan.

## Membuka dan membuat APK
1. Instal Android Studio versi yang mendukung Android Gradle Plugin 8.7.3.
2. Buka folder `KeuanganPribadi` melalui Android Studio.
3. Tunggu Gradle Sync selesai (memerlukan internet untuk mengunduh plugin Android Gradle).
4. Hubungkan HP Android dengan USB debugging aktif atau gunakan emulator.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

`applicationId`: `id.keuangan.pribadi` · `minSdk`: 23 (Android 6.0).

## Catatan penting
Ini adalah prototipe awal. Saldo rekening dimulai dari Rp0; sebelum penggunaan nyata, tambahkan saldo awal melalui transaksi pemasukan. Uji alur dan lakukan pencadangan sebelum menyimpan data penting. Data saat ini tersimpan lokal di WebView dan belum memiliki fitur ekspor/impor atau enkripsi khusus.
