plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.keuangan.pribadi"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.keuangan.pribadi"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // Samakan target Java dan Kotlin ke versi 17 agar proses kompilasi berhasil.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
